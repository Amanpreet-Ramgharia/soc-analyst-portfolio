Place hardware photo + dashboard screenshots here.
